 # Booysen Accountants — website handover

## Implemented
Home, About and verified team, Services, six individual service pages, Contact, Insights & Resources, privacy information and a custom not-found page. Original logos and team photographs are retained. Other photography is illustrative—not represented as the firm’s own premises.

Contact form uses the managed database and typed API. It validates inputs on the server, requires consent, rejects honeypot input, throttles repeated enquiries from the same email and returns a reference only after a successful database insert. No enquiries are publicly readable. Direct phone, email and WhatsApp links use the verified source details.

## Before public launch
1. **Email notifications / staff access:** form enquiries currently persist in the database only. Connect an approved email delivery provider and implement staff notifications or a protected enquiry inbox before relying on the form operationally. No notification provider was configured, and no test email was sent to the firm. The confirmation transparently states this limitation. Direct email, call and WhatsApp links work independently.
2. **Production domain / SEO:** publish through the platform. After the final domain is confirmed, configure absolute canonical and Open Graph URLs, generate a production-domain sitemap and robots file, submit to Search Console, and configure redirects from the original site if you control it. Unique page titles/descriptions and AccountingService structured data are implemented. Route-specific metadata is currently rendered by React; pre-rendering should be evaluated for non-JavaScript crawlers. No search ranking guarantee.
3. **Privacy:** firm approval is required for the new enquiry data handling, retention period, staff access, processor arrangements and existing policy coverage. Existing privacy and PAIA documents are linked, not replaced. Platform-provided analytics remains enabled; review any necessary disclosure/consent before launch.
4. **Office details:** all contact details reflect the supplied Core page. That page spells the Greytown street “Shepsone” and gives Jacobs Bay as “Jacobsbay, Cape Town, 7395”; these were preserved instead of silently guessing corrections. Map links search the published addresses, not unverified exact coordinates. Confirm them before launch.
5. **WhatsApp:** the source site links to +27127407703. The same number is used; the firm should verify account ownership and availability. Opening a wa.me link is implemented, but delivery of messages cannot be verified without contacting the firm.

## Verified
- Production build and TypeScript compile pass.
- Lint: zero warnings/errors.
- 13 route checks, including six services and 404; no browser JavaScript errors or broken loaded images.
- 24 responsive checks across 390, 768, 1024 and 1440px; no horizontal overflow after fixes.
- Mobile navigation, Escape close, menu routing and FAQ expansion.
- Service preselection, required-field validation, successful form persistence and receipt, duplicate throttling.
- Database read-back confirmed the QA record, consent and selected service. Test data removed afterwards.
- All internal linked destinations resolve; all ten linked Core publication/resource/legal pages returned HTTP 200.
- Phone/email/WhatsApp/map links reviewed for formatting; no real calls, messages or enquiries sent to the firm.

## Sources
- https://www.coregroup.digital/all-core-companies/booysen-accountants
- https://www.coregroup.digital/services/booysen-accountants
- https://www.coregroup.digital/contact/booysen-accountants

The original contact page contained email anchors pointing to another firm and a malformed telephone URI; both were corrected using the visible Booysen contact information. No testimonials, prices, additional qualifications or accreditations were invented.