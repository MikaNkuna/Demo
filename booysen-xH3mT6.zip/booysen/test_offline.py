import json
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/google-chrome', headless=True, args=['--no-sandbox'])
    context = browser.new_context(viewport={'width': 390, 'height': 844})
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto('http://localhost:4200/')
    page.get_by_text('Ready for offline browsing', exact=True).wait_for(timeout=30000)
    assert page.evaluate('Boolean(navigator.serviceWorker.controller)')
    page.get_by_role('button', name='Install website').click()
    page.get_by_role('heading', name='Keep Booysen with you.').wait_for()
    page.get_by_role('button', name='Close installation instructions').click()
    manifest = page.evaluate("async()=>await (await fetch('/manifest.webmanifest')).json()")
    assert manifest['name'] == 'Booysen Accountants'
    assert len(manifest['icons']) == 3
    context.set_offline(True)
    checks = []
    for route in ['/', '/about', '/services', '/services/accounting', '/services/taxation', '/services/advisory', '/services/cloud-accounting', '/services/payroll', '/services/assurance', '/contact', '/resources', '/privacy']:
        page.goto('http://localhost:4200'+route)
        page.wait_for_selector('h1')
        page.evaluate("async()=>{await document.fonts.ready;await Promise.all([...document.images].map(img=>{img.loading='eager';return img.decode().catch(()=>{})}));}")
        images = page.evaluate('[...document.images].filter(i=>!i.naturalWidth).map(i=>i.src)')
        overflow = page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert not images, (route, images)
        assert not overflow, route
        assert 'You’re offline.' in page.locator('.offline-banner').inner_text()
        checks.append({'route': route, 'offline': True, 'imagesLoaded': True, 'overflow': False})
    page.goto('http://localhost:4200/contact?service=Taxation')
    page.wait_for_selector('button[type=submit]')
    assert page.locator('button[type=submit]').is_disabled()
    assert page.locator('select[name=service]').input_value() == 'Taxation'
    assert page.evaluate("async()=>{const keys=await caches.keys();const cache=await caches.open(keys.find(k=>k.startsWith('booysen-offline-')));return !(await cache.keys()).some(r=>new URL(r.url).pathname.startsWith('/api/'));}")
    page.screenshot(path='/home/user/booysen-offline-contact.png', full_page=True)
    # A new browser page can open a route not visited during the online session.
    fresh = context.new_page()
    fresh.goto('http://localhost:4200/services/cloud-accounting')
    fresh.get_by_role('heading', name='Your business. Connected.').wait_for()
    context.set_offline(False)
    assert page.locator('button[type=submit]').is_enabled()
    assert page.locator('.offline-banner').count() == 0
    report = {'routes': checks, 'freshOfflineNavigation': True, 'enquiriesDisabledOffline': True, 'reenabledOnline': True, 'noApiCache': True, 'browserErrors': errors}
    assert not errors, errors
    open('offline-test-results.json','w').write(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    browser.close()