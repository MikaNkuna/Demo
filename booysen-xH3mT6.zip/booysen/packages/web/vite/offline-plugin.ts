import { readdirSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import type { Plugin } from "vite";

export default function offlinePlugin(): Plugin {
  let publicDir: string;
  return {
    name: "booysen-offline",
    apply: "build",
    configResolved(config) {
      publicDir = resolve(config.publicDir);
    },
    generateBundle(_options, bundle) {
      const files = readdirSync(publicDir, { recursive: true, withFileTypes: true })
        .filter((entry) => entry.isFile() && !entry.name.startsWith("."))
        .map((entry) =>
          resolve(entry.parentPath, entry.name).slice(publicDir.length).replaceAll("\\", "/"),
        );
      const urls = [
        ...new Set(["/index.html", ...Object.keys(bundle).map((key) => `/${key}`), ...files]),
      ];
      const hash = createHash("sha256");
      for (const file of files) hash.update(readFileSync(resolve(publicDir, file.slice(1))));
      for (const item of Object.values(bundle))
        hash.update(item.type === "chunk" ? item.code : item.source);
      const cache = `booysen-offline-${hash.digest("hex").slice(0, 12)}`;
      this.emitFile({
        type: "asset",
        fileName: "sw.js",
        source: `
const CACHE = ${JSON.stringify(cache)};
const PRECACHE = ${JSON.stringify(urls)};
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('booysen-offline-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('message', event => {
  if (event.data === 'OFFLINE_STATUS' && event.ports[0]) {
    event.waitUntil(caches.open(CACHE).then(cache => cache.match('/index.html')).then(shell => event.ports[0].postMessage({ready: Boolean(shell)})));
  }
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/') || url.pathname === '/sw.js') return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.open(CACHE).then(cache => cache.match('/index.html'))));
    return;
  }
  event.respondWith(caches.open(CACHE).then(async cache => {
    const cached = await cache.match(request);
    if (cached) return cached;
    return fetch(request);
  }));
});
`,
      });
    },
  };
}
