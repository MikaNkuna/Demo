import { z } from "zod";
import { ORPCError } from "@orpc/server";
import { and, eq, gte } from "drizzle-orm";
import { base } from "../__core/app";
import { db } from "../database";
import { enquiries as table } from "../database/schema";

export const enquiries = {
  create: base
    .input(
      z.object({
        name: z.string().trim().min(2).max(100),
        email: z
          .string()
          .trim()
          .email()
          .max(254)
          .transform((v) => v.toLowerCase()),
        phone: z.string().trim().max(40),
        company: z.string().trim().max(150),
        service: z.enum([
          "Accounting & bookkeeping",
          "Taxation",
          "Business advisory",
          "Cloud accounting",
          "Payroll",
          "Assurance",
          "Not sure yet",
        ]),
        office: z.enum(["Midstream", "Greytown", "Jacobs Bay", "Online / no preference"]),
        message: z.string().trim().min(20).max(4000),
        consent: z.literal(true),
        website: z.string().max(0),
      }),
    )
    .handler(async ({ input, context }) => {
      const origin = context.headers.get("origin");
      const host = context.headers.get("host");
      if (origin && host && new URL(origin).host !== host) throw new ORPCError("FORBIDDEN");
      const recent = await db
        .select({ id: table.id })
        .from(table)
        .where(
          and(eq(table.email, input.email), gte(table.createdAt, new Date(Date.now() - 60_000))),
        )
        .limit(1);
      if (recent.length)
        throw new ORPCError("TOO_MANY_REQUESTS", {
          message: "Please wait a minute before submitting another enquiry.",
        });
      const id = `BA-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
      const { website: _trap, ...values } = input;
      await db.insert(table).values({ ...values, id });
      return { reference: id };
    }),
};
