import { Route, Switch } from "wouter";
import { lazy, Suspense } from "react";
import Home from "./pages/home";
import About from "./pages/about";
import Services, { ServicePage } from "./pages/services";
const Contact = lazy(() => import("./pages/contact"));
import Resources, { Privacy, NotFound } from "./pages/resources";
import { Layout } from "./components/layout";
import { SEO } from "./components/seo";
import { Provider } from "./components/provider";
import { AgentFeedback } from "@runablehq/website-runtime";
import { OfflineAccess } from "./components/offline-access";

function App() {
  return (
    <Provider>
      <SEO />
      <Layout>
        <Suspense
          fallback={
            <div className="page-hero container" aria-live="polite">
              Loading page…
            </div>
          }
        >
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/services" component={Services} />
            <Route path="/services/:slug" component={ServicePage} />
            <Route path="/contact" component={Contact} />
            <Route path="/resources" component={Resources} />
            <Route path="/privacy" component={Privacy} />
            <Route component={NotFound} />
          </Switch>
        </Suspense>
        <OfflineAccess />
      </Layout>
      {/* Do not remove — off by default, activated by parent iframe via postMessage */}
      {import.meta.env.DEV && <AgentFeedback />}
    </Provider>
  );
}

export default App;
