export const core = "https://www.coregroup.digital";
export const email = "info@booysengroup.co.za";
export const whatsapp =
  "https://wa.me/27127407703?text=Hello%20Booysen%20Accountants%2C%20I%20would%20like%20to%20discuss%20your%20services.";
export const offices = [
  {
    name: "Midstream",
    province: "Gauteng",
    address: "Co-Work at Midstream, Mount Quray Road, Midlands Office Park West, Midstream, 1692",
    phone: "+27 (0) 12 740 7703",
    tel: "+27127407703",
  },
  {
    name: "Greytown",
    province: "KwaZulu-Natal",
    address: "Unit 3, Cnr. Pine & Shepsone Street, Greyperm Heights, Greytown, 3250",
    phone: "+27 (0) 33 417 1936",
    tel: "+27334171936",
  },
  {
    name: "Jacobs Bay",
    province: "Western Cape",
    address: "Jacobsbay, Cape Town, 7395",
    phone: "+27 (0) 12 740 7703",
    tel: "+27127407703",
  },
];
export const services = [
  {
    slug: "accounting",
    title: "Accounting & bookkeeping",
    short: "Clarity in every number.",
    description:
      "Accurate financial information, dependable reporting and practical insight. We take care of the detail so you can focus on running your business.",
    items: [
      "Monthly processing and management accounts",
      "Annual financial statements and historical analysis",
      "Accounting treatments for complex transactions",
      "Accounting and regulatory advice",
      "Tax returns and administration",
      "Budgets, analysis and cash flow forecasting",
      "Accounting systems and internal controls",
      "Group structures for tax efficiency",
      "Business growth advice and strategic planning",
    ],
  },
  {
    slug: "taxation",
    title: "Taxation",
    short: "Plan ahead. Stay compliant.",
    description:
      "Navigate a changing tax environment with considered advice. We support individuals, companies, entrepreneurs, family businesses, trusts and partnerships across South Africa.",
    items: [
      "Individual and corporate tax compliance",
      "Tax calculations and return submissions",
      "Transaction structuring and tax planning",
      "Legally minimising taxation liabilities",
      "VAT and transfer duty",
      "Securities transfer tax",
      "Taxation training and updates",
      "Other related tax services",
    ],
  },
  {
    slug: "advisory",
    title: "Business advisory",
    short: "A clearer path forward.",
    description:
      "From start-up decisions to the next stage of growth, we work closely with owners and directors to understand their objectives and provide practical, personalised advice.",
    items: [
      "Outsourced financial management",
      "Business and cash flow management advice",
      "Reorganisation and restructuring",
      "Business valuations",
      "Tax planning",
      "Succession planning",
    ],
  },
  {
    slug: "cloud-accounting",
    title: "Cloud accounting",
    short: "Your business. Connected.",
    description:
      "Bring your accounting into a more connected working environment. Cloud systems, real-time financial reporting and system integration make your information easier to access and use.",
    items: [
      "Cloud system implementation and integration",
      "Online accounting processing",
      "Payslip processing and compilation",
      "VAT compilation and submission",
      "Compensation Commissioner and EMP",
      "Financial performance and monthly reports",
      "Cash flow management",
      "Bank reconciliations",
      "Supplier invoice processing",
    ],
  },
  {
    slug: "payroll",
    title: "Payroll",
    short: "Your people, properly supported.",
    description:
      "Professional, confidential payroll support tailored to your business. Our cloud-based solutions help you manage payroll processing and legislative compliance.",
    items: [
      "Monthly or weekly payroll processing",
      "Payroll consultation",
      "Payment processing services",
      "Payroll tax compliance",
      "COIDA / Workmen’s Compensation Fund services",
    ],
  },
  {
    slug: "assurance",
    title: "Assurance",
    short: "Confidence in your reporting.",
    description:
      "Reviews, compilations and agreed-upon procedures that support reliable financial reporting. We help you understand risk, improve controls and meet regulatory requirements.",
    items: [
      "Special-purpose engagements",
      "Internal audit optimisation",
      "IFRS reporting",
      "Systems and control procedures",
      "Independent reviews",
      "Regulatory compliance",
      "Agreed-upon procedures",
    ],
  },
];
export const team = [
  { name: "Johan Booysen", role: "Founder & Director", image: "johan" },
  {
    name: "Monique Booysen",
    role: "Payroll, Secretarial & Tax Administration · Compliance Specialist",
    image: "monique",
  },
  { name: "Louise Lategan", role: "Practice Manager", image: "louise" },
  { name: "Thuthukani Lombo", role: "Senior Accountant", image: "thuthukani" },
  { name: "Clarize Bezuidenhout", role: "Trainee Accountant", image: "clarize" },
  {
    name: "Tarien Barnard",
    role: "Professional Accountant (SA) · Senior Accounting Manager",
    image: "tarien",
  },
];
export const articles = [
  {
    category: "BUSINESS & TECHNOLOGY",
    title: "Is it possible for AI to make your business more profitable?",
    author: "Hein Du Plessis",
    url: "/post/is-it-possible-for-ai-to-make-your-business-more-profitable",
    image: "meeting",
  },
  {
    category: "GROWTH & FINANCE",
    title: "Unlocking growth: commercial finance for strategic advantage",
    author: "Henning Pretorius",
    url: "/post/unlocking-growth-how-businesses-can-leverage-commercial-finance-for-strategic-advantage",
    image: "architecture",
  },
  {
    category: "TAX & PLANNING",
    title: "2026 Budget Update: savings, tax planning and retirement",
    author: "The Core Group",
    url: "/post/2026-budget-update-what-it-means-for-your-savings-tax-planning-and-retirement",
    image: "boardroom",
  },
];
