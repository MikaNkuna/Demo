import { useEffect } from "react";
import { useLocation } from "wouter";
import { offices, services } from "../lib/content";

export function SEO() {
  const [path] = useLocation();
  useEffect(() => {
    const pages: Record<string, [string, string]> = {
      "/": [
        "Accounting, Tax & Business Advisory",
        "Booysen Accountants: personal accounting, tax, cloud accounting, payroll and business advisory. Offices in Midstream, Greytown and Jacobs Bay. Established in 2011.",
      ],
      "/about": [
        "About Our Firm & Team",
        "Meet Booysen Accountants, founded by Johan Booysen in 2011. An independent, digitally connected practice serving South Africa and abroad.",
      ],
      "/services": [
        "Accounting & Financial Services",
        "Explore accounting, bookkeeping, taxation, business advisory, cloud accounting, payroll and assurance services from Booysen Accountants.",
      ],
      "/contact": [
        "Contact Our Midstream, Greytown & Jacobs Bay Offices",
        "Contact Booysen Accountants: info@booysengroup.co.za, +27 (0) 12 740 7703. Make an enquiry or find your nearest office.",
      ],
      "/resources": [
        "Business Insights & Resources",
        "Explore business insights, guides and newsletters from Booysen Accountants and The Core Group network.",
      ],
      "/privacy": [
        "Privacy & Access to Information",
        "Read how website enquiries are handled and access Booysen Accountants’ existing privacy policy and PAIA manual.",
      ],
    };
    const service = services.find((s) => path === `/services/${s.slug}`);
    const [title, desc] = service
      ? [service.title, service.description]
      : pages[path] || [
          "Page Not Found",
          "Return to Booysen Accountants to explore our firm and services.",
        ];
    document.title = `${title} | Booysen Accountants`;
    for (const [name, content] of [
      ["description", desc],
      ["og:title", document.title],
      ["og:description", desc],
    ]) {
      let el = document.querySelector<HTMLMetaElement>(
        `meta[${name.startsWith("og:") ? "property" : "name"}="${name}"]`,
      );
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(name.startsWith("og:") ? "property" : "name", name);
        document.head.appendChild(el);
      }
      el.content = content;
    }
    let ld = document.querySelector<HTMLScriptElement>("#business-schema");
    if (!ld) {
      ld = document.createElement("script");
      ld.id = "business-schema";
      ld.type = "application/ld+json";
      document.head.appendChild(ld);
    }
    ld.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "AccountingService",
      name: "Booysen Accountants",
      foundingDate: "2011",
      founder: { "@type": "Person", name: "Johan Booysen" },
      email: "info@booysengroup.co.za",
      telephone: "+27127407703",
      areaServed: "South Africa",
      department: offices.map((o) => ({
        "@type": "AccountingService",
        name: `Booysen Accountants — ${o.name}`,
        telephone: o.tel,
        address: { "@type": "PostalAddress", streetAddress: o.address, addressCountry: "ZA" },
      })),
    });
  }, [path]);
  return null;
}
