import {
  ArrowUpRight,
  BookOpen,
  ChartNoAxesCombined,
  Cloud,
  Layers3,
  ShieldCheck,
  Users,
  Plus,
  Check,
} from "lucide-react";
import { Link } from "wouter";
import { articles, core, offices, services } from "../lib/content";
import { ButtonLink, Eyebrow } from "./layout";

const icons = [BookOpen, Layers3, ChartNoAxesCombined, Cloud, Users, ShieldCheck];
export function ServiceGrid({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`service-grid ${compact ? "compact" : ""}`}>
      {services.map((s, i) => {
        const Icon = icons[i]!;
        return (
          <Link href={`/services/${s.slug}`} key={s.slug} className="service-card">
            <div className="service-top">
              <span className="service-icon">
                <Icon size={23} strokeWidth={1.35} />
              </span>
              <span className="service-number">0{i + 1}</span>
            </div>
            <h3>{s.title}</h3>
            <p>{compact ? s.short : s.description}</p>
            <div className="service-bottom">
              <span>Explore service</span>
              <ArrowUpRight size={20} />
            </div>
          </Link>
        );
      })}
    </div>
  );
}
export function Offices({ full = false }: { full?: boolean }) {
  return (
    <div className={`office-grid ${full ? "full" : ""}`}>
      {offices.map((o, i) => (
        <article className="office" key={o.name} id={o.name.toLowerCase().replaceAll(" ", "-")}>
          <div className="office-num">
            0{i + 1} / {o.province.toUpperCase()}
          </div>
          <h3>{o.name}</h3>
          {full && (
            <>
              <p className="address">{o.address}</p>
              <a href="mailto:info@booysengroup.co.za">info@booysengroup.co.za</a>
            </>
          )}
          <a href={`tel:${o.tel}`}>{o.phone}</a>
          <a
            className="gold-link"
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(o.address)}`}
            target="_blank"
            rel="noreferrer"
          >
            View on map <ArrowUpRight size={15} />
          </a>
        </article>
      ))}
    </div>
  );
}
export function ArticleGrid() {
  return (
    <div className="article-grid">
      {articles.map((a) => (
        <a className="article" href={core + a.url} target="_blank" rel="noreferrer" key={a.url}>
          <div className="article-image">
            <img src={`/images/${a.image}.webp`} alt="" loading="lazy" width="600" height="400" />
            <span>
              <ArrowUpRight size={20} />
            </span>
          </div>
          <div className="article-category">{a.category}</div>
          <h3>{a.title}</h3>
          <p>
            {a.author} <span>· The Core Group</span>
          </p>
        </a>
      ))}
    </div>
  );
}
const faqs = [
  [
    "How can Booysen Accountants support my business?",
    "We provide accounting and bookkeeping, taxation, business advisory, cloud accounting, payroll and assurance services. We’ll discuss your current position and priorities to identify the support that suits your business.",
  ],
  [
    "Do you work with clients outside your office locations?",
    "Yes. We use modern technology to support clients across South Africa and abroad. Our offices are in Midstream, Greytown and Jacobs Bay, and we can discuss a digital working arrangement.",
  ],
  [
    "Can you help us move to cloud accounting?",
    "Yes. Our services include cloud accounting implementation, system integration, online processing and financial reporting. We’ll first understand your existing systems and processes.",
  ],
  [
    "Can we outsource our payroll?",
    "Yes. We offer weekly or monthly payroll processing, payroll consultation, payment processing and related tax compliance, including COIDA / Workmen’s Compensation Fund services.",
  ],
  [
    "What should I prepare for an initial conversation?",
    "Share a short overview of your business, the services you are interested in and any immediate priorities. Please do not send tax numbers, banking details or confidential financial documents through this website form; secure document-sharing arrangements can be discussed separately.",
  ],
  [
    "How are your fees determined?",
    "Fees depend on the scope and requirements of your engagement. Contact us to discuss the support you need and request a tailored proposal; no standard fees are published on this website.",
  ],
];
export function FAQ() {
  return (
    <section className="faq-section container">
      <div className="section-heading centered">
        <Eyebrow>A LITTLE MORE CLARITY</Eyebrow>
        <h2>Your questions, answered.</h2>
      </div>
      <div className="faq-list">
        {faqs.map(([q, a]) => (
          <details key={q}>
            <summary>
              {q}
              <Plus size={19} />
            </summary>
            <p>{a}</p>
          </details>
        ))}
      </div>
      <p className="faq-note">
        Have something else in mind?{" "}
        <Link href="/contact">
          Let’s talk <ArrowUpRight size={14} />
        </Link>
      </p>
    </section>
  );
}
export function Process() {
  return (
    <section className="process container">
      <div className="section-heading">
        <div>
          <Eyebrow>A PERSONAL APPROACH</Eyebrow>
          <h2>
            Built around your business.
            <br />
            <em>Not the other way around.</em>
          </h2>
        </div>
        <p>Thoughtful advice starts with understanding what matters to you.</p>
      </div>
      <div className="process-grid">
        {[
          [
            "Understand",
            "We start with a conversation about your business, your priorities and where you want to go.",
          ],
          [
            "Bring clarity",
            "We identify the accounting, tax and advisory support that fits your needs.",
          ],
          [
            "Move forward",
            "We build an ongoing relationship, with useful information and proactive guidance.",
          ],
        ].map(([title, text], i) => (
          <div key={title}>
            <span className="process-number">0{i + 1}</span>
            <h3>{title}</h3>
            <p>{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
export function ServiceDetail({ slug }: { slug: string }) {
  const service = services.find((s) => s.slug === slug);
  if (!service)
    return (
      <section className="page-hero container">
        <h1>Service not found.</h1>
        <ButtonLink to="/services">Explore our services</ButtonLink>
      </section>
    );
  return (
    <>
      <section className="page-hero container">
        <Eyebrow>OUR EXPERTISE / {service.title.toUpperCase()}</Eyebrow>
        <h1>{service.short}</h1>
        <p>{service.description}</p>
        <ButtonLink to={`/contact?service=${encodeURIComponent(service.title)}`}>
          Discuss {service.title.toLowerCase()}
        </ButtonLink>
      </section>
      <section className="detail-section container">
        <div>
          <Eyebrow>HOW WE CAN HELP</Eyebrow>
          <h2>
            {service.title}
            <br />
            <em>with purpose.</em>
          </h2>
          <p>
            A tailored engagement, grounded in your business priorities. Contact us to discuss the
            scope of support you need.
          </p>
          <Link href="/services" className="gold-link">
            All services <ArrowUpRight size={16} />
          </Link>
        </div>
        <ul className="service-list">
          {service.items.map((item) => (
            <li key={item}>
              <Check size={18} />
              {item}
            </li>
          ))}
        </ul>
      </section>
      <section className="container related">
        <h2>Explore our other services</h2>
        <ServiceGrid compact />
      </section>
    </>
  );
}
