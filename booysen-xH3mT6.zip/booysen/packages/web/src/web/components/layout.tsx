import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowUpRight,
  ArrowRight,
  Menu,
  X,
  MessageCircle,
  Instagram,
  Facebook,
} from "lucide-react";
import { core, email, whatsapp } from "../lib/content";

export function ButtonLink({
  to = "/contact",
  children,
  secondary = false,
}: {
  to?: string;
  children: React.ReactNode;
  secondary?: boolean;
}) {
  return (
    <Link href={to} className={`button ${secondary ? "secondary" : ""}`}>
      {children}
      <ArrowUpRight size={17} />
    </Link>
  );
}
export function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <div className="eyebrow">
      <span />
      {children}
    </div>
  );
}
export function CallToAction() {
  return (
    <section className="cta container">
      <Eyebrow>YOUR NEXT CHAPTER</Eyebrow>
      <h2>
        Good decisions start with
        <br />
        <em>a better conversation.</em>
      </h2>
      <p>Tell us where you are. Let’s explore where you could go.</p>
      <ButtonLink>Let’s talk about your business</ButtonLink>
    </section>
  );
}
export function Layout({ children }: { children: React.ReactNode }) {
  const [path] = useLocation();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    setOpen(false);
    if (!window.location.hash) window.scrollTo(0, 0);
  }, [path]);
  useEffect(() => {
    if (!open) return;
    const handle = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", handle);
    return () => document.removeEventListener("keydown", handle);
  }, [open]);
  const links = [
    ["/", "Home"],
    ["/about", "About"],
    ["/services", "Services"],
    ["/resources", "Insights"],
  ];
  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <header className="header container">
        <Link href="/" className="brand" aria-label="Booysen Accountants home">
          <img src="/images/logo-white.png" alt="Booysen Accountants" width="220" height="64" />
        </Link>
        <nav
          className={`nav ${open ? "is-open" : ""}`}
          aria-label="Main navigation"
          id="main-navigation"
        >
          {links.map(([url, name]) => (
            <Link
              key={url}
              href={url}
              aria-current={path === url ? "page" : undefined}
              className={
                path === url || (url === "/services" && path.startsWith("/services/"))
                  ? "active"
                  : ""
              }
            >
              {name}
            </Link>
          ))}
          <Link href="/contact" className="mobile-contact">
            Contact us <ArrowUpRight size={16} />
          </Link>
        </nav>
        <Link href="/contact" className="header-contact">
          Let’s talk <ArrowUpRight size={16} />
        </Link>
        <button
          type="button"
          className="menu-toggle"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-controls="main-navigation"
          aria-label={open ? "Close navigation" : "Open navigation"}
        >
          {open ? <X /> : <Menu />}
        </button>
      </header>
      <main id="main">{children}</main>
      <footer className="footer">
        <div className="container footer-grid">
          <div className="footer-brand">
            <Link href="/" aria-label="Booysen Accountants home">
              <img src="/images/logo-white.png" alt="Booysen Accountants" width="225" height="65" />
            </Link>
            <p>
              Personal relationships.
              <br />
              Forward-thinking accounting.
            </p>
            <div className="socials">
              <a
                href="https://www.facebook.com/BooysenAcc"
                target="_blank"
                rel="noreferrer"
                aria-label="Booysen on Facebook"
              >
                <Facebook size={18} />
              </a>
              <a
                href="https://www.instagram.com/booysenaccountants/"
                target="_blank"
                rel="noreferrer"
                aria-label="Booysen on Instagram"
              >
                <Instagram size={18} />
              </a>
              <a href={whatsapp} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp">
                <MessageCircle size={18} />
              </a>
            </div>
          </div>
          <div>
            <h3>Explore</h3>
            <Link href="/about">Our firm</Link>
            <Link href="/services">Our services</Link>
            <Link href="/resources">Insights & resources</Link>
            <Link href="/contact">Contact us</Link>
          </div>
          <div>
            <h3>Our presence</h3>
            <Link href="/contact#midstream">Midstream, Gauteng</Link>
            <Link href="/contact#greytown">Greytown, KwaZulu-Natal</Link>
            <Link href="/contact#jacobs-bay">Jacobs Bay, Western Cape</Link>
            <span className="footer-muted">South Africa & beyond</span>
          </div>
          <div>
            <h3>Start a conversation</h3>
            <a href={`mailto:${email}`}>{email}</a>
            <a href="tel:+27127407703">+27 (0) 12 740 7703</a>
            <Link href="/contact" className="gold-link">
              Make an enquiry <ArrowRight size={16} />
            </Link>
          </div>
        </div>
        <div className="container footer-bottom">
          <span>© {new Date().getFullYear()} Booysen Accountants. All rights reserved.</span>
          <div>
            <Link href="/privacy">Privacy</Link>
            <a href={`${core}/paia/booysen-accountants`} target="_blank" rel="noreferrer">
              PAIA Manual <ArrowUpRight size={12} />
            </a>
            <a
              href={`${core}/all-core-companies/booysen-accountants`}
              target="_blank"
              rel="noreferrer"
            >
              Core Associated <ArrowUpRight size={12} />
            </a>
          </div>
        </div>
      </footer>
      <a
        className="whatsapp-float"
        href={whatsapp}
        target="_blank"
        rel="noreferrer"
        aria-label="Contact Booysen on WhatsApp"
      >
        <MessageCircle size={23} />
        <span>Let’s connect</span>
      </a>
    </>
  );
}
