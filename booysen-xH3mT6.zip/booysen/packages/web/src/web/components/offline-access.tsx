import { useEffect, useState } from "react";
import { Download, WifiOff, Check, X } from "lucide-react";
import { useOnline } from "../hooks/use-online";

interface InstallPrompt extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function OfflineAccess() {
  const online = useOnline();
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [prompt, setPrompt] = useState<InstallPrompt | null>(null);
  const [installed, setInstalled] = useState(
    window.matchMedia("(display-mode: standalone)").matches ||
      Boolean((navigator as Navigator & { standalone?: boolean }).standalone),
  );
  const [help, setHelp] = useState(false);
  useEffect(() => {
    const receive = (event: Event) => {
      event.preventDefault();
      setPrompt(event as InstallPrompt);
    };
    const done = () => {
      setInstalled(true);
      setPrompt(null);
      setHelp(false);
    };
    window.addEventListener("beforeinstallprompt", receive);
    window.addEventListener("appinstalled", done);
    return () => {
      window.removeEventListener("beforeinstallprompt", receive);
      window.removeEventListener("appinstalled", done);
    };
  }, []);
  useEffect(() => {
    if (import.meta.env.DEV || !window.isSecureContext || !("serviceWorker" in navigator)) return;
    let cancelled = false;
    const check = () => {
      const controller = navigator.serviceWorker.controller;
      if (!controller) return;
      const channel = new MessageChannel();
      channel.port1.onmessage = (event) => {
        if (!cancelled) setReady(event.data.ready === true);
        channel.port1.close();
      };
      controller.postMessage("OFFLINE_STATUS", [channel.port2]);
    };
    navigator.serviceWorker.addEventListener("controllerchange", check);
    navigator.serviceWorker
      .register("/sw.js", { updateViaCache: "none" })
      .then(() => navigator.serviceWorker.ready)
      .then(check)
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
      navigator.serviceWorker.removeEventListener("controllerchange", check);
    };
  }, []);
  useEffect(() => {
    if (!help) return;
    const escape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setHelp(false);
    };
    document.addEventListener("keydown", escape);
    return () => document.removeEventListener("keydown", escape);
  }, [help]);
  async function install() {
    if (prompt && ready) {
      await prompt.prompt();
      const choice = await prompt.userChoice;
      setPrompt(null);
      if (choice.outcome === "accepted") setInstalled(true);
    } else setHelp(!help);
  }
  return (
    <div className="offline-access">
      {!online && (
        <div className="offline-banner" aria-live="polite">
          <WifiOff size={16} />
          You’re offline. Browse cached pages; enquiries and external links need internet.
        </div>
      )}
      <div className="offline-tools container">
        <div className="offline-state" aria-live="polite">
          {ready ? (
            <>
              <Check size={15} />
              Ready for offline browsing
            </>
          ) : import.meta.env.DEV ? (
            "Offline installation is available on the published website."
          ) : failed ? (
            "Offline setup unavailable. Reconnect and reload to try again."
          ) : (
            "Preparing pages for offline browsing…"
          )}
        </div>
        {!installed ? (
          <button
            className="text-link gold-link"
            type="button"
            onClick={install}
            aria-expanded={help}
            aria-controls="offline-instructions"
          >
            <Download size={16} />
            Install website
          </button>
        ) : (
          <span className="offline-installed">
            <Check size={15} />
            Installed
          </span>
        )}
        {help && (
          <div id="offline-instructions" className="offline-help">
            <div>
              <h3>Keep Booysen with you.</h3>
              <button
                type="button"
                aria-label="Close installation instructions"
                onClick={() => setHelp(false)}
              >
                <X size={18} />
              </button>
            </div>
            <p>
              Open the published website directly in your browser—not inside the preview
              dashboard—and stay online until “Ready for offline browsing” appears.
            </p>
            <ul>
              <li>
                <strong>Chrome / Edge:</strong> use “Install website” when offered, or the install
                option in the browser’s address bar or menu.
              </li>
              <li>
                <strong>iPhone / iPad:</strong> open in Safari, tap Share, then “Add to Home Screen”
                and enable “Open as Web App” if shown.
              </li>
              <li>
                <strong>Other browsers:</strong> use “Add to Home Screen” or “Install” if supported.
              </li>
            </ul>
            <p>
              Local pages, services, team portraits and images are saved. External articles, maps,
              WhatsApp and sending enquiries still need internet. No enquiries are stored or queued
              for offline submission. Clearing browser storage removes the offline copy.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
