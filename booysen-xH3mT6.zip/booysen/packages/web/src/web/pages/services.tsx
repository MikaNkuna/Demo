import { ArrowUpRight } from "lucide-react";
import { ButtonLink, CallToAction, Eyebrow } from "../components/layout";
import { FAQ, ServiceDetail, ServiceGrid } from "../components/sections";
import { core } from "../lib/content";

export default function Services() {
  return (
    <>
      <section className="page-hero container">
        <Eyebrow>OUR SERVICES</Eyebrow>
        <h1>
          The expertise you need.
          <br />
          <em>The perspective you value.</em>
        </h1>
        <p>
          From the day-to-day detail to decisions that shape your future. Connected accounting, tax
          and advisory support, tailored to your business.
        </p>
        <ButtonLink>Discuss your needs</ButtonLink>
      </section>
      <section className="container services-page">
        <ServiceGrid />
      </section>
      <section className="association container">
        <div>
          <Eyebrow>SPECIALISED SUPPORT</Eyebrow>
          <h2>
            A single relationship.
            <br />
            <em>A wider world of expertise.</em>
          </h2>
        </div>
        <div>
          <p>
            Through our association with The Core Group, we can access specialised services beyond
            our own practice. Talk to us about your requirements and the appropriate support.
          </p>
          <a
            className="gold-link"
            href={`${core}/core-services/booysen-accountants`}
            target="_blank"
            rel="noreferrer"
          >
            Explore Core services <ArrowUpRight size={16} />
          </a>
        </div>
      </section>
      <FAQ />
      <CallToAction />
    </>
  );
}
export function ServicePage({ params }: { params: { slug: string } }) {
  return (
    <>
      <ServiceDetail slug={params.slug} />
      <CallToAction />
    </>
  );
}
