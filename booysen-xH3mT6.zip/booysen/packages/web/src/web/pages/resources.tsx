import { ArrowUpRight, BookOpen, Newspaper, BriefcaseBusiness } from "lucide-react";
import { ArticleGrid } from "../components/sections";
import { ButtonLink, CallToAction, Eyebrow } from "../components/layout";
import { core } from "../lib/content";

export default function Resources() {
  return (
    <>
      <section className="page-hero container">
        <Eyebrow>INSIGHTS & RESOURCES</Eyebrow>
        <h1>
          A wider perspective.
          <br />
          <em>A more informed tomorrow.</em>
        </h1>
        <p>
          Business thinking, practical guides and publications from our wider Core network. Ideas to
          support your next conversation.
        </p>
      </section>
      <section className="container resources-section">
        <div className="section-heading">
          <h2>Informed perspectives</h2>
          <span className="muted">From The Core Group</span>
        </div>
        <ArticleGrid />
        <p className="resource-note">
          Articles open on The Core Group website. They are general information, not advice tailored
          to your circumstances.
        </p>
      </section>
      <section className="container resource-grid">
        {[
          [
            "Business guides",
            "Explore practical resources for business owners and decision-makers.",
            "guides",
            BookOpen,
          ],
          [
            "Newsletters",
            "Stay connected to the firm’s existing newsletter publications.",
            "newsletters",
            Newspaper,
          ],
          [
            "Careers",
            "Explore the existing careers page for accounting opportunities.",
            "careers",
            BriefcaseBusiness,
          ],
        ].map(([title, text, path, Icon]) => {
          const I = Icon as typeof BookOpen;
          return (
            <a
              key={String(path)}
              href={`${core}/${path}/booysen-accountants`}
              target="_blank"
              rel="noreferrer"
              className="resource-card"
            >
              <I size={27} />
              <h3>{String(title)}</h3>
              <p>{String(text)}</p>
              <span className="gold-link">
                Explore resource <ArrowUpRight size={16} />
              </span>
            </a>
          );
        })}
      </section>
      <CallToAction />
    </>
  );
}
export function Privacy() {
  return (
    <section className="container legal">
      <Eyebrow>PRIVACY & ACCESS TO INFORMATION</Eyebrow>
      <h1>
        Your information
        <br />
        <em>deserves care.</em>
      </h1>
      <h2>Website enquiries</h2>
      <p>
        The enquiry form collects your name, email address, optional phone and business name,
        selected service and office, message and consent. These details are stored in the website’s
        database to record your enquiry and support a response. Please do not submit sensitive
        financial documents, identification numbers or banking details through this form.
      </p>
      <p>
        Automatic email notifications are not yet enabled. You can contact Booysen Accountants
        directly at <a href="mailto:info@booysengroup.co.za">info@booysengroup.co.za</a> to discuss
        your enquiry or ask about access, correction or deletion of your information.
      </p>
      <h2>Existing legal documents</h2>
      <p>
        The firm’s existing privacy policy and PAIA manual remain available through The Core Group.
        Those documents are maintained by the firm and have not been rewritten here.
      </p>
      <div className="legal-links">
        <a
          className="button secondary"
          href={`${core}/privacy/booysen-accountants`}
          target="_blank"
          rel="noreferrer"
        >
          Read the privacy policy <ArrowUpRight size={16} />
        </a>
        <a
          className="button secondary"
          href={`${core}/paia/booysen-accountants`}
          target="_blank"
          rel="noreferrer"
        >
          View PAIA manual <ArrowUpRight size={16} />
        </a>
      </div>
      <h2>Third-party links</h2>
      <p>
        WhatsApp, map searches, social platforms and Core publications open third-party websites,
        whose privacy policies apply when you use those services.
      </p>
      <p className="resource-note">
        Before public launch, the firm must approve the enquiry process, retention period and access
        arrangements, and confirm its legal documents cover the redesigned website. This page is an
        explanation of the implemented form, not a legal compliance certification.
      </p>
    </section>
  );
}
export function NotFound() {
  return (
    <section className="page-hero container">
      <Eyebrow>404 / PAGE NOT FOUND</Eyebrow>
      <h1>A different direction.</h1>
      <p>The page you’re looking for isn’t here. Let’s get you back to the right place.</p>
      <ButtonLink to="/">Return to home</ButtonLink>
    </section>
  );
}
