import { ArrowUpRight } from "lucide-react";
import { ButtonLink, CallToAction, Eyebrow } from "../components/layout";
import { core, team } from "../lib/content";
import { Process } from "../components/sections";

export default function About() {
  return (
    <>
      <section className="page-hero container">
        <Eyebrow>OUR FIRM</Eyebrow>
        <h1>
          Professional by nature.
          <br />
          <em>Personal by choice.</em>
        </h1>
        <p>
          A forward-thinking accounting practice, built on strong relationships and a shared
          commitment to your business.
        </p>
      </section>
      <section className="about-story container">
        <div className="story-image">
          <img
            src="/images/meeting.webp"
            alt="Modern meeting space, illustrating collaborative working"
            width="1100"
            height="733"
          />
          <span className="image-label">ESTABLISHED 2011 · LOOKING FORWARD</span>
        </div>
        <div>
          <Eyebrow>OUR STORY</Eyebrow>
          <h2>
            Independent thinking.
            <br />
            <em>Lasting relationships.</em>
          </h2>
          <p>
            Johan Booysen founded Booysen Accountants in 2011. Today, we support businesses and
            individuals from our offices in Midstream, Gauteng; Greytown, KwaZulu-Natal; and Jacobs
            Bay, Western Cape.
          </p>
          <p>
            Modern technology connects our team with clients across South Africa and abroad. From
            monthly accounting and cloud system implementation to tax planning and business
            valuations, we shape our support around the needs of each business.
          </p>
          <p>
            We are a registered practice dedicated to accounting, taxation and payroll services—with
            a focus on practical advice, relevant information and long-term relationships.
          </p>
        </div>
      </section>
      <section className="values container">
        <div className="section-heading centered">
          <Eyebrow>WHAT GUIDES US</Eyebrow>
          <h2>
            Integrity in the detail.
            <br />
            <em>Purpose in the bigger picture.</em>
          </h2>
        </div>
        <div className="values-grid">
          {[
            ["Honesty", "Open communication and doing the right thing."],
            ["Efficiency", "Working with discipline, focus and a sense of urgency."],
            ["Accountability", "Taking ownership of our actions and decisions."],
            ["Mutual respect", "Working as a team and respecting every stakeholder."],
          ].map(([a, b], i) => (
            <div key={a}>
              <span>0{i + 1}</span>
              <h3>{a}</h3>
              <p>{b}</p>
            </div>
          ))}
        </div>
        <div className="mission">
          <p>
            <span>OUR VISION</span>To be seen and experienced as globally trusted professionals.
          </p>
          <p>
            <span>OUR PURPOSE</span>To create diverse solutions that increase stakeholders’ profits,
            business value and personal wealth through a single core relationship.
          </p>
        </div>
      </section>
      <section className="team-section container">
        <div className="section-heading">
          <div>
            <Eyebrow>THE PEOPLE BEHIND THE PARTNERSHIP</Eyebrow>
            <h2>Meet your team.</h2>
          </div>
          <p>
            Expertise with a personal touch.
            <br />A shared commitment to your progress.
          </p>
        </div>
        <div className="founder">
          <div className="portrait">
            <img
              src="/images/johan.webp"
              alt="Johan Booysen, founder and director"
              loading="lazy"
              width="700"
              height="700"
            />
          </div>
          <div>
            <div className="eyebrow">FOUNDER & DIRECTOR</div>
            <h3>Johan Booysen</h3>
            <p>
              Johan began his accounting career with SAIPA articles in Klerksdorp, North-West. After
              completing his studies through UNISA and moving to Gauteng, he established Booysen
              Accountants in 2011.
            </p>
            <p>
              His hands-on involvement in accounting, taxation and payroll projects informs the
              firm’s practical approach. Under his leadership, the practice has embraced digital
              transformation while maintaining a personal, cost-effective service.
            </p>
            <ButtonLink secondary>Connect with our team</ButtonLink>
          </div>
        </div>
        <div className="team-grid">
          {team.slice(1).map((t) => (
            <article key={t.name}>
              <div className="portrait">
                <img
                  src={`/images/${t.image}.webp`}
                  alt={t.name}
                  loading="lazy"
                  width="700"
                  height="700"
                />
              </div>
              <h3>{t.name}</h3>
              <p>{t.role}</p>
            </article>
          ))}
        </div>
      </section>
      <section className="association container">
        <div className="core-mark">
          CORE<span>ASSOCIATED</span>
        </div>
        <div>
          <Eyebrow>INDEPENDENT. CONNECTED.</Eyebrow>
          <h2>Our firm. A broader network.</h2>
          <p>
            Booysen Accountants is associated with The Core Group, an association of independent
            professionals. We remain independently owned and managed, while drawing on The Core
            Service Companies for access to a wider range of specialised support.
          </p>
          <a
            href={`${core}/core-services/booysen-accountants`}
            target="_blank"
            rel="noreferrer"
            className="gold-link"
          >
            Explore our Core association <ArrowUpRight size={16} />
          </a>
        </div>
      </section>
      <Process />
      <CallToAction />
    </>
  );
}
