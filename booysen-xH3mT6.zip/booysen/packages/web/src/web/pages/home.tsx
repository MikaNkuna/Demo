import { ArrowDown, ArrowUpRight, ShieldCheck, Cloud, Handshake } from "lucide-react";
import { Link } from "wouter";
import { ButtonLink, CallToAction, Eyebrow } from "../components/layout";
import { ArticleGrid, FAQ, Offices, Process, ServiceGrid } from "../components/sections";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="hero-glow" />
        <div className="container hero-content">
          <Eyebrow>BOOYSEN ACCOUNTANTS · THE FUTURE — NOW</Eyebrow>
          <h1>
            Beyond the numbers.
            <br />
            <em>Closer to your ambitions.</em>
          </h1>
          <p>
            Forward-thinking accounting, tax and advisory.
            <br className="desktop-break" /> A personal partnership for your next chapter of growth.
          </p>
          <div className="hero-actions">
            <ButtonLink>Start a conversation</ButtonLink>
            <Link href="/services" className="text-link">
              Explore our expertise <ArrowUpRight size={16} />
            </Link>
          </div>
          <div className="hero-footnote">
            <span className="live-dot" />
            PERSONAL SERVICE. NATIONAL REACH.
          </div>
        </div>
        <div className="hero-photo">
          <img
            src="/images/architecture.webp"
            alt="Sculptural modern architecture with warm evening light"
            width="1700"
            height="1275"
            fetchPriority="high"
          />
          <div className="photo-caption">
            <span>A CLEARER PERSPECTIVE.</span>
            <a href="#introduction" aria-label="Discover Booysen Accountants">
              <ArrowDown size={20} />
            </a>
            <span>A STRONGER TOMORROW.</span>
          </div>
        </div>
      </section>
      <div className="trust-strip container">
        <span>
          <Handshake size={19} />
          Relationship-led
        </span>
        <span>
          <Cloud size={19} />
          Digitally connected
        </span>
        <span>
          <ShieldCheck size={19} />
          Established in 2011
        </span>
        <span className="core-word">
          CORE<span>ASSOCIATED</span>
        </span>
      </div>
      <section className="intro container" id="introduction">
        <div>
          <Eyebrow>MORE THAN ACCOUNTING</Eyebrow>
          <h2>
            Your business is personal.
            <br />
            <em>So is our approach.</em>
          </h2>
        </div>
        <div className="intro-copy">
          <p>
            Behind every business is an ambition. We help you see the financial picture clearly—and
            make informed decisions about what comes next.
          </p>
          <p>
            Founded by Johan Booysen in 2011, our digitally connected practice combines accounting,
            taxation and payroll expertise with a genuine commitment to your goals.
          </p>
          <Link href="/about" className="gold-link">
            Get to know our firm <ArrowUpRight size={17} />
          </Link>
        </div>
      </section>
      <section className="expertise container">
        <div className="section-heading">
          <div>
            <Eyebrow>OUR EXPERTISE</Eyebrow>
            <h2>
              Considered advice.
              <br />
              Comprehensive support.
            </h2>
          </div>
          <Link href="/services" className="text-link">
            View all services <ArrowUpRight size={17} />
          </Link>
        </div>
        <ServiceGrid compact />
      </section>
      <section className="partnership container">
        <div className="partnership-image">
          <img
            src="/images/boardroom.webp"
            alt="An elegant boardroom, illustrating space for considered conversations"
            width="1100"
            height="619"
            loading="lazy"
          />
          <div className="image-label">PERSPECTIVE. PARTNERSHIP. PROGRESS.</div>
        </div>
        <div className="partnership-copy">
          <Eyebrow>THE RIGHT PARTNER</Eyebrow>
          <h2>
            Confidence today.
            <br />
            <em>Possibility tomorrow.</em>
          </h2>
          <p>
            Your accountant should do more than look backwards. We help you understand your
            position, anticipate challenges and find a practical way forward.
          </p>
          <ul>
            <li>Personal relationships, not one-size-fits-all advice</li>
            <li>Accurate, relevant information when you need it</li>
            <li>Modern digital systems with a human touch</li>
          </ul>
          <ButtonLink to="/about" secondary>
            Discover the Booysen approach
          </ButtonLink>
        </div>
      </section>
      <Process />
      <section className="presence container">
        <div className="section-heading">
          <div>
            <Eyebrow>LOCAL ROOTS. A WIDER PERSPECTIVE.</Eyebrow>
            <h2>
              Three offices.
              <br />
              <em>One connected practice.</em>
            </h2>
          </div>
          <p>
            Based in South Africa.
            <br />
            Supporting clients here and abroad.
          </p>
        </div>
        <Offices />
        <Link href="/contact" className="gold-link presence-link">
          Find your nearest team <ArrowUpRight size={17} />
        </Link>
      </section>
      <section className="insights container">
        <div className="section-heading">
          <div>
            <Eyebrow>INFORMED PERSPECTIVES</Eyebrow>
            <h2>Ideas for what’s next.</h2>
          </div>
          <Link href="/resources" className="text-link">
            More insights <ArrowUpRight size={17} />
          </Link>
        </div>
        <ArticleGrid />
      </section>
      <FAQ />
      <CallToAction />
    </>
  );
}
