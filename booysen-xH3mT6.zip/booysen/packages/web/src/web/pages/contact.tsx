import { useState } from "react";
import { ArrowUpRight, CheckCircle2, Mail, MessageCircle, Phone, LoaderCircle } from "lucide-react";
import { Link } from "wouter";
import { Eyebrow } from "../components/layout";
import { Offices } from "../components/sections";
import { email, services, whatsapp } from "../lib/content";
import { useCreateEnquiry } from "../queries/enquiries";
import { useOnline } from "../hooks/use-online";

export default function Contact() {
  const create = useCreateEnquiry();
  const online = useOnline();
  const suggested = new URLSearchParams(window.location.search).get("service") || "Not sure yet";
  const [service, setService] = useState(
    services.some((s) => s.title === suggested) ? suggested : "Not sure yet",
  );
  const [formError, setFormError] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError("");
    if (!navigator.onLine) {
      setFormError(
        "You’re offline. Reconnect before sending your enquiry. Nothing has been submitted or queued.",
      );
      return;
    }
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") || "").trim();
    const message = String(data.get("message") || "").trim();
    if (name.length < 2 || message.length < 20) {
      setFormError("Please enter your name and a message of at least 20 characters.");
      return;
    }
    try {
      await create.mutateAsync({
        name,
        email: String(data.get("email")),
        phone: String(data.get("phone") || ""),
        company: String(data.get("company") || ""),
        service: service as "Not sure yet",
        office: String(data.get("office")) as "Online / no preference",
        message,
        consent: true,
        website: String(data.get("website") || ""),
      });
    } catch (err) {
      setFormError(
        err instanceof Error
          ? err.message
          : "We couldn’t save your enquiry. Please try again or contact us directly.",
      );
    }
  }
  return (
    <>
      <section className="page-hero container contact-hero">
        <Eyebrow>START A CONVERSATION</Eyebrow>
        <h1>
          Your next step
          <br />
          <em>starts here.</em>
        </h1>
        <p>
          Tell us what matters to your business.
          <br />
          Let’s explore how we can move forward together.
        </p>
      </section>
      <section className="contact-section container">
        <div className="contact-copy">
          <Eyebrow>LET’S CONNECT</Eyebrow>
          <h2>
            A personal conversation.
            <br />A clearer way forward.
          </h2>
          <p>
            Whether you need ongoing accounting support, guidance on a specific challenge or a fresh
            perspective, we’d like to hear from you.
          </p>
          <div className="contact-options">
            <a href={`mailto:${email}`}>
              <Mail size={19} />
              <div>
                <span>EMAIL OUR TEAM</span>
                {email}
              </div>
              <ArrowUpRight size={16} />
            </a>
            <a href="tel:+27127407703">
              <Phone size={19} />
              <div>
                <span>CALL OUR OFFICE</span>+27 (0) 12 740 7703
              </div>
              <ArrowUpRight size={16} />
            </a>
            <a href={whatsapp} target="_blank" rel="noreferrer">
              <MessageCircle size={19} />
              <div>
                <span>WHATSAPP</span>Start a conversation
              </div>
              <ArrowUpRight size={16} />
            </a>
          </div>
          <div className="contact-note">
            Prefer to meet in person?
            <br />
            Find our three office locations below.
          </div>
        </div>
        <div className="form-panel">
          {create.isSuccess ? (
            <div className="form-success" aria-live="polite">
              <CheckCircle2 size={42} />
              <Eyebrow>ENQUIRY SAVED</Eyebrow>
              <h2>
                Thank you for
                <br />
                reaching out.
              </h2>
              <p>Your enquiry has been saved securely.</p>
              <div className="receipt">
                Your reference: <strong>{create.data.reference}</strong>
              </div>
              <p className="small">
                For immediate assistance, please call or email our team. Automatic email
                notifications are not yet enabled on this website.
              </p>
              <a
                href={`mailto:${email}?subject=${encodeURIComponent("Website enquiry " + create.data.reference)}`}
                className="button"
              >
                Email our team <ArrowUpRight size={17} />
              </a>
              <button className="text-link" onClick={() => create.reset()}>
                Send another enquiry
              </button>
            </div>
          ) : (
            <form onSubmit={submit}>
              <h3>How can we help?</h3>
              <p className="form-intro">A few details to begin a meaningful conversation.</p>
              <div className="form-grid">
                <label>
                  Your name <span>*</span>
                  <input
                    name="name"
                    aria-label="Your name"
                    required
                    minLength={2}
                    maxLength={100}
                    autoComplete="name"
                    placeholder="Full name"
                  />
                </label>
                <label>
                  Email address <span>*</span>
                  <input
                    name="email"
                    aria-label="Email address"
                    type="email"
                    required
                    maxLength={254}
                    autoComplete="email"
                    placeholder="you@company.co.za"
                  />
                </label>
                <label>
                  Phone number
                  <input
                    name="phone"
                    aria-label="Phone number"
                    type="tel"
                    maxLength={40}
                    autoComplete="tel"
                    placeholder="Your contact number"
                  />
                </label>
                <label>
                  Business name
                  <input
                    name="company"
                    aria-label="Business name"
                    maxLength={150}
                    autoComplete="organization"
                    placeholder="Company or organisation"
                  />
                </label>
                <label>
                  I’m interested in <span>*</span>
                  <select
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    name="service"
                  >
                    {["Not sure yet", ...services.map((s) => s.title)].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </label>
                <label>
                  Preferred office
                  <select name="office" defaultValue="Online / no preference">
                    {["Online / no preference", "Midstream", "Greytown", "Jacobs Bay"].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </label>
              </div>
              <label>
                Tell us a little more <span>*</span>
                <textarea
                  name="message"
                  aria-label="Tell us a little more"
                  required
                  minLength={20}
                  maxLength={4000}
                  rows={4}
                  placeholder="Your business, your priorities, and how we might help…"
                />
              </label>
              <p className="form-hint">
                Please don’t include tax numbers, banking details or confidential financial
                documents.
              </p>
              <div className="honeypot" aria-hidden="true">
                <label>
                  Website
                  <input name="website" aria-label="Website" tabIndex={-1} autoComplete="off" />
                </label>
              </div>
              <label className="consent">
                <input
                  type="checkbox"
                  name="consent"
                  aria-label="Consent to store and respond to my enquiry"
                  required
                />
                <span>
                  I agree to my details being stored and used to respond to this enquiry. Read our{" "}
                  <Link href="/privacy">privacy information</Link>. <b>*</b>
                </span>
              </label>
              {formError && (
                <p className="form-error" role="alert">
                  {formError}
                </p>
              )}
              {!online && (
                <p className="form-error" role="alert">
                  You’re offline. Reconnect to send your enquiry. Nothing is submitted or queued
                  while offline.
                </p>
              )}
              <button
                className="button submit-button"
                type="submit"
                disabled={create.isPending || !online}
              >
                {create.isPending ? (
                  <>
                    <LoaderCircle className="spin" size={18} />
                    Saving your enquiry…
                  </>
                ) : (
                  <>
                    Send enquiry
                    <ArrowUpRight size={17} />
                  </>
                )}
              </button>
              <p className="form-required">
                * Required fields · Internet required to submit · No obligation to proceed
              </p>
            </form>
          )}
        </div>
      </section>
      <section className="container contact-offices">
        <div className="section-heading">
          <div>
            <Eyebrow>OUR OFFICES</Eyebrow>
            <h2>
              Close to your business.
              <br />
              <em>Wherever you are.</em>
            </h2>
          </div>
          <p>
            Visit by arrangement.
            <br />
            We also work with clients digitally.
          </p>
        </div>
        <Offices full />
        <p className="address-note">
          Addresses reproduced from the firm’s existing contact page. Map links search those
          addresses; please confirm directions with the office before visiting.
        </p>
      </section>
    </>
  );
}
