# Booysen Accountants — Design

Offline extension: installable web app with Booysen-only identity, dark app icons, a restrained footer installation control, cache-ready status and explicit offline contact warning. Production service worker caches all local build files (including lazy page bundles and self-hosted media/fonts), never API requests or external pages. No offline enquiry queue or personal-data persistence. No changes to the brand layout, platform analytics or mobile/desktop packages.

> Starter design brief. Replace this content with the app you're building before writing any UI.
> Keep it short and concrete — it's the single source of truth for palette, typography, pages,
> screens, and flows across web, mobile, and desktop.

Premium responsive accounting website. Supplied reference guides the dark atmospheric background, centered editorial headlines, pill navigation, photography strip and generous whitespace. Preserve original Booysen blue and original logo, with subtle brushed gold. No reference text, invented claims, testimonials or client logos.

## Brand & Colors

One token set, consumed per platform:

- **Web & desktop**: CSS variables in `packages/web/src/web/styles.css` (desktop loads the web UI).
- **Mobile**: `Colors.light` / `Colors.dark` in `packages/mobile/constants/theme.ts`, read via `useColors()`; `userInterfaceStyle: "automatic"` follows the system light/dark setting.

| Token | Light | Dark | Use |
|-------|-------|------|-----|
| primary | #216e96 | #c7aa72 | Original blue / brushed gold accents |
| background | #f4f1e9 | #080f18 | Ivory / midnight |
| card | #e9e6de | #141e2a | Tonal panels |
| foreground | #171717 | #f4f1e9 | Primary text |
| mutedForeground | #555555 | #a8b2c0 | Secondary text |
| border | #d0ccc3 | #2b3543 | Hairlines |
| destructive | #DC2626 | #EF4444 | Delete / errors |

## Typography

Self-hosted Manrope headings and body; italic Cormorant Garamond for selective editorial accents. Desktop headline 72px / mobile 44px. Body 16px, generous 1.75 line-height. 1200px content width, 80–120px sections, 24px mobile gutters. Photography illustrative, not represented as firm premises. 12px panel radius, subtle blue atmosphere, thin gold rules, accessible contrast and reduced-motion support.

## Pages & Screens

Web only: Home; About with verified history and team; Services with deep links; Resources linking to existing Core articles, guides and newsletters; Contact with verified three offices; Privacy information with existing legal links; 404. No mobile or desktop package changes.

## Key User Flows

1. Visitor explores services → contact CTA preselects service → form validation and consent → database persistence → receipt reference.
2. Click-to-call, corrected email links, verified WhatsApp, map searches, responsive menu and FAQ accordions.
3. All links keyboard accessible. Loading and error states, honeypot and throttling; no public enquiry listings. Email notifications explicitly identified as requiring configuration.

## Architecture

- **API**: typed oRPC client (`lib/api.ts` in each package) → the backend in `@template/web`. Query/mutation hooks live in `queries/` (one file per feature); pages/screens call them with `@tanstack/react-query`.
- **State/sync**: TanStack Query with optimistic updates for instant-feel interactions.
- **Enquiries**: public create procedure only, Drizzle enquiries table. SEO: unique titles/descriptions, structured data, semantic headings. Final domain needed for canonical and sitemap configuration.
