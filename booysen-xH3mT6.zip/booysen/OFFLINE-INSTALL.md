 # Install Booysen Accountants for offline use

The website now includes an installable web app with Booysen branding. There is no ZIP or app-store download: installation is through a supported browser.

## Install
1. Publish the updated website through the platform, using HTTPS.
2. Open its published URL directly in your browser, outside the Runable preview dashboard.
3. Stay online until the footer says **Ready for offline browsing**. This confirms the local site files have been cached.
4. Use **Install website** in the footer, or your browser’s installation option.
   - **Chrome / Edge:** use the installation prompt, address-bar icon or browser menu.
   - **iPhone / iPad:** open in Safari → Share → Add to Home Screen. Enable Open as Web App if offered.
5. Launch Booysen from the installed icon. Local pages are available without internet after the initial cache finishes.

If your browser does not support installation, cached offline browsing can still work in that browser. Browser storage policies may remove cached data; reconnect and visit again if that happens.

## Offline availability
- Home, About, Services, six service detail pages, Contact, Insights & Resources and privacy information.
- Local photography, team portraits, icons, styles and self-hosted fonts.
- Fresh navigation and reloads of local routes, even if the route was not viewed during the initial online visit.

## Internet required
- Sending enquiries. The submit button is disabled offline; no enquiry is queued or saved locally. The original database-backed form operates online, with its existing notification configuration limitation.
- WhatsApp, map searches, external articles, social links, privacy documents hosted externally and resources on The Core Group website.
- Updates to the offline copy. New builds use versioned caches and replace the previous cache after successful installation.

The production service worker never caches API requests or external pages. The app does not store form entries in browser storage. Platform analytics remains unchanged.

## Verification
Production build and lint pass. Chrome browser testing verified all 12 local routes offline, local images loaded, no mobile horizontal overflow, a fresh offline service-page navigation, no API cache, and enquiry submission disabling/re-enabling on connection changes. No browser JavaScript errors occurred. Native installation UI on physical iPhone/Android devices has not been tested here.

Offline installation is enabled in the published production build, not in the development preview. Publication and domain settings are managed in the platform UI.