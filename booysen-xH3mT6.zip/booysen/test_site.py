from playwright.sync_api import sync_playwright
import json

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1440,'height':1000})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    results = []
    for route in ['/', '/about','/services','/services/accounting','/services/taxation','/services/advisory','/services/cloud-accounting','/services/payroll','/services/assurance','/resources','/contact','/privacy','/missing-page']:
        page.goto('http://localhost:4200'+route)
        page.wait_for_selector('h1')
        results.append({'route':route,'h1':page.locator('h1').inner_text(),'title':page.title(),'overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth'), 'brokenImages':page.evaluate('[...document.images].filter(i=>i.complete&&!i.naturalWidth).map(i=>i.src)')})
    page.goto('http://localhost:4200/')
    page.locator('details summary').first.click()
    assert page.locator('details').first.get_attribute('open') is not None
    for width in [390,768,1024]:
        page.set_viewport_size({'width':width,'height':900})
        for route in ['/','/about','/services','/contact','/resources']:
            page.goto('http://localhost:4200'+route)
            page.wait_for_selector('h1')
            results.append({'width':width,'route':route,'overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth')})
    page.set_viewport_size({'width':390,'height':844})
    page.goto('http://localhost:4200/')
    page.get_by_role('button',name='Open navigation').click()
    assert page.locator('#main-navigation').is_visible()
    page.keyboard.press('Escape')
    assert not page.locator('#main-navigation').is_visible()
    page.get_by_role('button',name='Open navigation').click()
    page.locator('#main-navigation').get_by_role('link',name='Services',exact=True).click()
    assert page.url.endswith('/services')
    page.set_viewport_size({'width':1440,'height':1000})
    page.goto('http://localhost:4200/contact?service=Taxation')
    assert page.locator('select[name=service]').input_value() == 'Taxation'
    page.locator('button[type=submit]').click()
    assert page.locator('input[name=name]').evaluate('(e)=>!e.validity.valid')
    page.locator('input[name=name]').fill('Website QA Test')
    page.locator('input[name=email]').fill('website-qa@example.com')
    page.locator('input[name=company]').fill('Internal website testing')
    page.locator('textarea').fill('Internal QA test only. Please disregard this test enquiry.')
    page.locator('input[name=consent]').check()
    page.locator('button[type=submit]').click()
    page.get_by_text('ENQUIRY SAVED',exact=True).wait_for(timeout=15000)
    results.append({'formSaved':True,'reference':page.locator('.receipt').inner_text()})
    page.screenshot(path='/home/user/contact-success.png',full_page=True)
    page.get_by_role('button',name='Send another enquiry').click()
    page.locator('input[name=name]').fill('Website QA Test')
    page.locator('input[name=email]').fill('website-qa@example.com')
    page.locator('textarea').fill('Internal QA test to verify duplicate submission throttling.')
    page.locator('input[name=consent]').check()
    page.locator('button[type=submit]').click()
    page.locator('[role=alert]').wait_for(timeout=15000)
    results.append({'rateLimit':page.locator('[role=alert]').inner_text()})
    for route in ['/','/contact','/about']:
        page.goto('http://localhost:4200'+route)
        page.set_viewport_size({'width':1440,'height':1000})
        page.screenshot(path='/home/user/'+(route.strip('/') or 'home')+'-full-desktop.png',full_page=True)
        page.set_viewport_size({'width':390,'height':844})
        page.screenshot(path='/home/user/'+(route.strip('/') or 'home')+'-full-mobile.png',full_page=True)
    report = {'checks':results,'browserErrors':errors}
    open('/home/user/booysen/test-results.json','w').write(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    browser.close()